# FoodDash – MERN food delivery app (Zomato-style)

MongoDB + Express + React (Vite) + Node.

## Features (from the screen recording)
- Search by restaurant or dish, cuisine chips, Veg Mode
- Filters: Near & Fast, Under ₹150, Rating 4.0+, sort
- Restaurant page with menu, veg filter, ADD / +/- stepper, cart bar
- Cart, coupons (SAVE75, FLAT175), server-calculated bill
- Login/Register (JWT), saved addresses, payment choice, place order, order history

## Run
Prerequisite: Node 18+ and MongoDB running locally (or an Atlas URI).

```bash
# 1. Backend
cd server
cp .env.example .env      # edit MONGO_URI / JWT_SECRET
npm install
npm run seed              # loads sample restaurants
npm run dev               # http://localhost:5000

# 2. Frontend (new terminal)
cd client
npm install
npm run dev               # http://localhost:5173
```

## API
| Method | Route | Auth |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | – |
| GET | /api/auth/me | ✔ |
| POST/DELETE | /api/auth/address, /api/auth/address/:id | ✔ |
| GET | /api/restaurants (q, cuisine, veg, fast, under150, rating, sort) | – |
| GET | /api/restaurants/meta/cuisines, /api/restaurants/:id | – |
| POST | /api/orders/quote | – |
| POST | /api/orders | ✔ |
| GET | /api/orders/my, /api/orders/:id | ✔ |
